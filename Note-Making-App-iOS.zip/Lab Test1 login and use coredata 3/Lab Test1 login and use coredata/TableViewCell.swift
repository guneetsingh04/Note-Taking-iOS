//
//  TableViewCell.swift
//  Lab Test1 login and use coredata
//
//   Created by Gurpreet Verma on 2017-11-28.
//  Copyright © 2017 Gurpreet Verma. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

     var itemInfo : MemoryInfo!
    var parent : Main_TableViewController!
    @IBAction func clickMap(_ sender: Any) {
        
        parent.OpenMapView(itemInfo)
    }
   
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var viewDate: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
   
    
    
    @IBAction func clickButton(_ sender: Any) {
        
      
        parent.popupEditMemoryView(itemInfo: itemInfo)
    }
    
    @IBAction func clickPhoto(_ sender: Any) {
         
        parent.OpenMemoryView(itemInfo)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
