//
//  ViewController.swift
//  Lab Test1 login and use coredata
//
//   Created by Gurpreet Verma on 2017-11-28.
//  Copyright © 2017 Gurpreet Verma. All rights reserved.
//

import UIKit

class Login_ViewController: UIViewController {
    
    @IBAction func clickLogin(_ sender: Any) {
        
        
                        self.MoveOnMainView()
                    }
    
    
    
    func MoveOnMainView() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let tableView = storyboard.instantiateViewController(withIdentifier: "Memories") as? Main_TableViewController {
           
            navigationController?.pushViewController(tableView, animated: true)
        }
    }
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
      
        self.MoveOnMainView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      
        print(segue.destination);
        if segue.identifier == "seg_Memories" {
            let vc_dest = segue.destination as! Main_TableViewController
            
        }
    }
}

