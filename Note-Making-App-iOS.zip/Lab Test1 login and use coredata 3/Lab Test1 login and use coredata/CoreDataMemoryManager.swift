//
//  CoreDataManager.swift
//  Lab Test1 login and use coredata
//
//   Created by Gurpreet Verma on 2017-11-28.
//  Copyright © 2017 Gurpreet Verma. All rights reserved.
//

import UIKit
import CoreData



class CoreDataMemoryManager {
    
    public static func Add(item : MemoryInfo!) -> Bool {
        
       // let moc = Facade.getContext()
        let moc = getContext()
        guard let entityMem = NSEntityDescription.entity(forEntityName: "Memories", in: moc) else {
            // handle failed new object in moc
            print("moc error : Memories")
            return false
        }
        
        let memoryData = NSManagedObject(entity: entityMem, insertInto: moc) as? MemoryData
        
        // assign object id
        item.objID = memoryData?.objectID

        memoryData?.id = item.id
        //set image data of thumbnail
        memoryData?.imageData = item.imgSrc as NSData?
        //memoryData?.audioData = imageData as NSData
       
        memoryData?.name = item.title
        memoryData?.desciption = item.desc
        memoryData?.date = item.date
    
        // save the new objects
        do {
            try moc.save()
        } catch {
            fatalError("Failure to save context: \(error)")
        }
        // clear the moc
        moc.refreshAllObjects()
        return true
    }
    
    // Gets a person by id
    static func getById(id: NSManagedObjectID) -> MemoryData? {
        //return Facade.getContext().object(with: id) as? MemoryData
        return getContext().object(with: id) as? MemoryData
    }
    
    static func DeleteById(objID: NSManagedObjectID) {
       // let moc = Facade.getContext()
        let moc = getContext()
        
        if let data = moc.object(with: objID) as? MemoryData {
          
            moc.delete(data)

            // save the new objects
            do {
                try moc.save()
            } catch {
                fatalError("Failure to save context: \(error)")
            }
            
        }
    }
    
    // Gets all with an specified predicate.
    // Predicates examples:
    // - NSPredicate(format: "name == %@", "Juan Carlos")
    // - NSPredicate(format: "name contains %@", "Juan")
    static func get(withPredicate queryPredicate: NSPredicate) -> [MemoryData]{
      //  let context = Facade.getContext();
        let context = getContext();
        let fetchRequest: NSFetchRequest<MemoryData> = MemoryData.fetchRequest()
        
        fetchRequest.predicate = queryPredicate
        
        do {
            let response = try context.fetch(fetchRequest)
            
            return response
            
        } catch let error as NSError {
            // failure
            print(error)
            return [MemoryData]()
        }
    }
    
    static func Update(item : MemoryInfo!) -> Bool {
        
        // get by id
        if let data = getById(id: item.objID as! NSManagedObjectID){
            data.name = item.title
            data.desciption = item.desc
           
            data.imageData = item.imgSrc as NSData?
            
            // Save Changes
            do{
               // try Facade.getContext().save()
                try getContext().save()
            } catch let error as NSError {
                // failure
                print(error)
            }
            return true
        }
        return false
    }

 
    public static func FetchAll() -> [MemoryData] {
        //let context = Facade.getContext()
        let context = getContext()
        let request : NSFetchRequest<MemoryData> = MemoryData.fetchRequest()
       // let fetchRequest = NSFetchRequest(entityName: "Message")
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        request.sortDescriptors = [sortDescriptor]
        request.returnsObjectsAsFaults = false;
        
        do {
            let results = try context.fetch(request)
            return results;
        }
        catch {
        }
        return [MemoryData]()
        
    }
    
    /////////////////////////////////////////////////////
    // format: "id==\(withID)"
    public static func DeleteData(format: String) -> Bool {
        
        let fetchRequest: NSFetchRequest<MemoryData> = MemoryData.fetchRequest()
        fetchRequest.predicate = NSPredicate.init(format: format)
       // let context = Facade.getContext();
        let context = getContext();
        
        do {
            let items = try! context.fetch(fetchRequest)
            
            for item in items {
                context.delete(item)
            }
            
            // Save Changes
            try context.save()
            
        } catch {
            fatalError("Failure to delete context: \(error)")
        }
        return true
    }
    public static func getContext() -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }

    
    
    
}
