//
//  ViewMemory_ViewController.swift
//  Lab Test1 login and use coredata
//
//  Created by Gurpreet Verma on 2017-11-28.
//  Copyright © 2017 Gurpreet Verma. All rights reserved.
//

import UIKit
import AVFoundation

class ViewMemory_ViewController: UIViewController , AVAudioPlayerDelegate {

    @IBOutlet weak var txtDesc: UITextView!
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgView: UIImageView!
  
    var itemInfo : MemoryInfo!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imgView.image = UIImage( data : itemInfo.imgSrc! )
        lblTitle.text = itemInfo.title
        txtDesc.text = itemInfo.desc
        
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
       
    }

  

}
