//
//  NewMemoryViewController.swift
//  Lab Test1 login and use coredata
//
//  Created by Gurpreet Verma on 2017-11-28.
//  Copyright © 2017 Gurpreet Verma. All rights reserved.
//

import UIKit
import CoreLocation
import CoreData
import MapKit


class FormMemory_ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, CLLocationManagerDelegate {
     var dataMemory : MemoryInfo!
   var mapData: [Double] = []
    @IBAction func goMap(_ sender: Any) {
        //gooMap(itemInfo: dataMemory)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let view = storyboard.instantiateViewController(withIdentifier: "view_map") as? locationView {
            view.itemInfo = dataMemory
            
            navigationController?.pushViewController(view, animated: true)
        }
        
    }
    
    var isEditMode = false
    var isDeleted = false

    var uid : Double = Date().timeIntervalSince1970
  

    @IBOutlet weak var btnDelete: UIBarButtonItem!
    
    @IBOutlet weak var btnSubmit: UIButton!
    
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var objPicture: UIImageView!
    @IBOutlet weak var txtDesc: UITextView!
    
    @IBOutlet weak var longiTude: UILabel!
    @IBOutlet weak var latiTude: UILabel!
    var lati:Double = 0.0
    var longi:Double = 0.0
 
    
  let manager =  CLLocationManager()
    
    var Loc = CLLocation()
   func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[0]
       lati = Double(location.coordinate.latitude)
        longi = Double(location.coordinate.longitude)
    Loc = location
    }
    
    let imagePicker = UIImagePickerController()
    // dispatch queues
    let convertQueue = DispatchQueue(label: "convertQueue", attributes: .concurrent)
    let saveQueue = DispatchQueue(label: "saveQueue", attributes: .concurrent)
    
    
    func getContext() -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if self.dataMemory != nil {
            isEditMode = true
            self.uid = (self.dataMemory?.id)!
            objPicture.image = UIImage( data : (self.dataMemory?.imgSrc)! )
            txtTitle.text = self.dataMemory?.title
            txtDesc.text = self.dataMemory?.desc
           /* let la = String(describing: self.dataMemory?.lati)
            latiTude.text = la
            let lo = String(describing: self.dataMemory?.longi)
           longiTude.text = lo*/
            
        } else {
          
            manager.delegate = self
            manager.desiredAccuracy = kCLLocationAccuracyBest
            manager.requestWhenInUseAuthorization()
            manager.startUpdatingLocation()
         
        }
        
        imagePickerSetup()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func clickPicture(_ sender: Any) {
        // using imagePicker and image source from PhotoLibrary
        imagePicker.allowsEditing = false
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        //imagePicker.sourceType = .savedPhotosAlbum
        //imagePicker.sourceType = .camera
        present(imagePicker, animated: true, completion: nil)
         
    }
    
 
    //
  
    func imagePickerSetup() {
        
        imagePicker.delegate = self
        imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            objPicture.contentMode = .scaleToFill
            objPicture.image = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    
    ///////////////////////////////////
    func SaveMemoryData(image:UIImage) {
        
            let thumbnail = image.scale(toSize: self.view.frame.size)
            
            guard let thumbnailData  = UIImageJPEGRepresentation(thumbnail, 0.4) else {
                // handle failed conversion
                print("jpg error")
                return
            }
        
            if(self.dataMemory == nil) {
                self.dataMemory = MemoryInfo(self.uid)
            }
            self.dataMemory?.title = self.txtTitle.text!
            self.dataMemory?.desc = self.txtDesc.text!
      //let currentDate = Date()
        //var date1 = String(describing: currentDate)
        self.dataMemory?.date = Date()
      /* let loc = CLLocation()
        let lati = Double(loc.coordinate.latitude)
        let longi = Double(loc.coordinate.longitude)*/
       
  
        let key = self.txtTitle.text!
       mapData.insert(lati, at: 0)
        mapData.insert(longi, at: 1)
    UserDefaults.standard.set(mapData, forKey: key)
       //var si = dataMemory.loc
        let a = lati
        let b = longi
    
        
      
            self.dataMemory?.imgSrc = thumbnailData
            
            //saveQueue.async() {
            // create new objects in moc
                if self.isEditMode {
                    if !CoreDataMemoryManager.Update(item: self.dataMemory!) {
                        print("error")
                    }
                }
                else {
                    if !CoreDataMemoryManager.Add(item: self.dataMemory!) {
                        print("error")
                    }
                }
            //}

        
        //}
    }
    
    

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        // cancel condition
        let btn = sender as? NSObject
        
        if(btn == btnSubmit) {
            SaveMemoryData(image: objPicture.image!)
            guard (navigationController?.popViewController(animated:true)) != nil
                else {
                    print("save success")
                    return
            }
        }
        else if btn == btnDelete {
            print("delete")
            self.isDeleted = true
            CoreDataMemoryManager.DeleteById(objID: dataMemory?.objID as! NSManagedObjectID)
            //dataMemory = nil
            return
        }
        else {
            print("cancel")
            dataMemory = nil
        }
      }
    func gooMap(itemInfo : MemoryInfo) {
        
       
    }

}
