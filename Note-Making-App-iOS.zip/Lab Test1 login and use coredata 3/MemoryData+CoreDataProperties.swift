//
//  MemoryData+CoreDataProperties.swift
//  Lab Test1 login and use coredata
//
//   Created by Gurpreet Verma on 2017-11-28.
//  Copyright © 2017 Gurpreet Verma. All rights reserved.
//

import Foundation
import CoreData
import CoreLocation


@objc(MemoryData)
public class MemoryData: NSManagedObject {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<MemoryData> {
        return NSFetchRequest<MemoryData>(entityName: "Memories");
      
        
        
    }

  
    @NSManaged public var desciption: String?
    @NSManaged public var id: Double
    @NSManaged public var imageData: NSData?
    @NSManaged public var name: String?
    @NSManaged public var date: Date?
   // @NSManaged public var lati: Double
   // @NSManaged public var longi: Double
    //@NSManaged public var loc: NSCoder
  
    

}
